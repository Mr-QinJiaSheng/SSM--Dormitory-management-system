## DormitorySystem 
![IDE](https://img.shields.io/badge/IDE-IntelliJ%20IDEA-brightgreen.svg) ![Java](https://img.shields.io/badge/Java-1.8-blue.svg) ![Database](https://img.shields.io/badge/Database-MySQL-lightgrey.svg) 
- 毕业设计💼
- MD5加密🔒
- SSM框架🎨
- Layui框架🎄

#### 实现功能
- [x] 管理员的登录与登出  
- [x] 管理员,班级,学生,宿舍，卫生，访客各模块增删改查  
- [x] 个别模块关联查询  
- [x] 各个模块数据导出Excel

#### 一些截图
![dorm1](http://image.zxkidea.top/dorm1.png)

![dorm1](http://image.zxkidea.top/dorm2.png)

![dorm1](http://image.zxkidea.top/dorm3.png)

![dorm1](http://image.zxkidea.top/dorm4.png)


